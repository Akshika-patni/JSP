package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Employee;

public class EmployeeDao {
	public static Connection getConnection()
	{
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment","root","rat");
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return con;	
	}
	public static int addEmployee( Employee e)
	{
		int status=0;
		Connection con=getConnection();
		try {
			PreparedStatement ps=con.prepareStatement("insert into employee(eId,eName,eDesig,salary)values(?,?,?,?)");
		  ps.setInt(1, e.geteId());
		  ps.setString(2, e.geteName());
		  ps.setString(3, e.geteDesig());
		  ps.setInt(4, e.getSalary());
		  status=ps.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			return status;
	}
	
	public static int deleteEmployee(Employee e)
	{
		int status=0;
		Connection con=getConnection();
		try {
			PreparedStatement ps= con.prepareStatement("delete from employee where eId=?");
	ps.setInt(1, e.geteId());
	status=ps.executeUpdate();
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return status;
	}
	public static int updateEmployee(Employee e)
	{
		int status=0;
		Connection con=getConnection();
		try {
			PreparedStatement ps=con.prepareStatement("update employee set eName=?,eDesig=?,salary=? where eId=?");
		ps.setString(1,e.geteName());
		ps.setString(2, e.geteDesig());
		ps.setInt(3, e.getSalary());
		ps.setInt(4, e.geteId());
		status=ps.executeUpdate();
		
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return status;
	}
	public static List<Employee> getallDetails()
	{  List<Employee> list=new ArrayList<Employee>();
		Connection con=getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from employee");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Employee e=new Employee();
				e.seteId(rs.getInt(1));
				e.seteName(rs.getString(2));
				e.seteDesig(rs.getString(3));
				e.setSalary(rs.getInt(4));
				list.add(e);	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}

}
