package com.cg.bean;

public class Employee {
	private int eId;
	private String eName;
	private String eDesig;
	private int salary;
	
	public Employee(int eId, String eName, String eDesig, int salary) {
		super();
		this.eId = eId;
		this.eName = eName;
		this.eDesig = eDesig;
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String geteDesig() {
		return eDesig;
	}
	public void seteDesig(String eDesig) {
		this.eDesig = eDesig;
	}
	public int getSalary() {
		return salary;
	}
	
	public void setSalary(int salary) {
		this.salary = salary;
	}
	

}
